This directory contains a set of media files to be used with the STM32Cube projects:

- Audio: contains a set of audio (*.mp3) and (*.wav) files
- Pictures: contains a set of image (*.bmp) and (*.jpg) files
- Video: contains a movie (*.avi and *.emf) files
- ClockandWeather: config file for clock and weather demonstration

