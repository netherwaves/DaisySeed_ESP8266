
#include "mbed.h"
#include "objects.h"

DigitalOut myled(LED1);

int main() {

    while(1) {
        myled = 1;
        wait(1);
        myled = 0;
        wait(1);
    }
}
